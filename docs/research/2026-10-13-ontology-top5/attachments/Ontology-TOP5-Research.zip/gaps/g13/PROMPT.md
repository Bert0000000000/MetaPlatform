# G13 执行 Prompt

将下面正文复制给实施者。只实施这一项；这份 prompt 不包含其他工单的授权，也不意味着调研者已实现功能。

---

你在 Bert0000000000/MetaPlatform 实施 `G13`：SPARQL 兼容端点明确拒绝未执行的 INSERT/DELETE。先读当前仓库 AGENTS.md、该工单 [PRD](PRD.md) 与 [交付要求](../../DELIVERY-STANDARD.md)，从最新 main 建隔离分支，保存 Git/WIP/工作树状态。

调研基线 `dc8980d3e129e94f0bc55190705ede7cbe304ba0`，定位文件 `mate-platform-backend/packages/mate-tech-ont/src/mate_tech_ont/sparql/api.py`（约第 54 行）。必须先核对差距是否仍存在：parser 识别 INSERT/DELETE，但 execute_sparql 非 SELECT 直接返回 []，端点仍可能 200；调用者会把空成功当写入已执行。该路径是 legacy 兼容 API，不能替代 v2 Kernel。 若已有可靠修复，输出当前代码与验收证据，不重复改代码。

只完成：仅在 HTTP 执行端点显式拒绝 INSERT/DELETE/UNKNOWN，返回明确的既有错误结构/受契约支持状态；保留 SELECT 与独立解释/翻译工具。

范围边界：不实现 SPARQL UPDATE，不引入 RDF store，不改变 v2 对象写入接口或 Neo4j 占位路径。

操作链：兼容端点收到写语句 → 明确不支持且无写入；支持的 SELECT 仍返回原结果。

按本工单 60 分钟有效工作预算执行：5 分钟复现/设计、20 分钟实现、15 分钟测试、15 分钟独立发布/回滚、5 分钟证据。已有环境必须就绪；CI 排队、首次安装或目标不可用记录真实阻塞，不跳过门禁、不把未部署标为部署成功。

验收必须逐项核对：

- [ ] INSERT、DELETE、未知操作不能以 200+空绑定表示已执行。
- [ ] 有/无 tenant context 与外租户负例保留；任何拒绝请求均无实例变更。
- [ ] SELECT 行为与返回结构回归，不把 explain 的翻译结果当执行结果。

测试要求：ASGI/API 回归覆盖三类拒绝、SELECT、缺身份与拒绝后的存储计数；如现有 contract 未登记该兼容 route，先对齐契约并完成相关 lint。 先写能触发当前问题的有效反例，再做最小实现。实际测试路径由你创建/确认并记入日志，不执行文档里的占位路径。前端运行当前 worktree 的 typecheck、目标 Vitest 与 build，以及必要的真实 Playwright 操作；后端使用当前 Python3.12 venv、受控非特权数据库及相关回归。契约先行，受影响 required CI 必须在当前 SHA 通过。

部署要求：仅 ont 应用镜像，现有兼容消费者需确认错误语义；无迁移。 先在该分支独立环境验证；只有单项 PR 获准合入 main 后，走现有受信 main 发布流程核对云端。无需本轮其他新工单先完成。rollback：上一 ont 应用镜像，记录兼容端点行为变化。

保留全部既有 WIP、工作树、数据库、卷、凭据和预览。沿用现有路由/Semi UI/Kernel/租户上下文。不要创建第二套 ontology store；不要重置共享数据库或服务。Mock、fault injection、真实接口、数据库、云端发布分别记证据。不得改 Accepted/Gate/Goal Board 状态以宣布完成。

交付一个小范围 PR，引用本工单 issue；正文说明问题→行为→测试→候选/云端部署状态→回滚证据。最终返回改动文件、真实命令/结果、SHA、耗时、验收 checklist 和仍未覆盖的边界。不要仅返回“已完成”或“CI 绿”。

## 给用户看的文案示例

成功：“本次操作已完成，请核对当前对象与结果。”
失败：“本次操作未完成：<服务返回的可理解原因>。”
范围：“结果仅覆盖本次选择与已执行能力。”

上面的例句仅作语气参考；实施时必须替换为本项真实动作/对象，不能显示技术占位符或泛化成全部本体已正确。
